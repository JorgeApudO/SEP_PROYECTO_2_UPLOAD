//void update_edit_state();
//int printEditGui();
